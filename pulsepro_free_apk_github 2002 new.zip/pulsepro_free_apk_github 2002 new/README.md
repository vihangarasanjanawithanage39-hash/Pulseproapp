# PulsePro — Direct Offline Android APK (No Netlify)

## ෆෝන් එකෙන්ම PulsePro.apk හදාගන්නා පියවර 4:
1. [GitHub.com](https://github.com) හි නොමිලේ ගිණුමක් සාදා අලුත් Repository එකක් (`pulsepro-apk`) සාදන්න.
2. මෙම ZIP ගොනුව Unzip කර, ඇතුළේ ඇති සියලුම ෆයිල් සහ ෆෝල්ඩර (`www`, `.github`, `package.json`, `capacitor.config.json`) GitHub Repository එකට Upload කර **Commit changes** ඔබන්න.
3. GitHub හි ඉහළ **Actions** ටැබ් එක ඔබන්න — **Build PulsePro Direct APK** ස්වයංක්‍රීයව ක්‍රියාත්මක වී විනාඩි 3කින් කොළ පාට ✓ වැටේ.
4. එය ඔබා පහළ **Artifacts → PulsePro-APK** බාගත කර Unzip කළාම සැබෑ **`PulsePro.apk`** ගොනුව ලැබේ!
